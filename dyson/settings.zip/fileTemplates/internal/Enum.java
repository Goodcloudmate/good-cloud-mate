#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
  *@enumName ${NAME}
  *Description TODO
  *Author cds
  *Date ${DATE} ${TIME}
  *Version 1.0
  **/
public enum ${NAME} {
}
